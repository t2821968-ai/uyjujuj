package com.severoyug.game;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
